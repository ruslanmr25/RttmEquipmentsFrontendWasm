export default (function (o, c) {
  var proto = c.prototype;

  proto.toArray = function () {
    return [this.$y, this.$M, this.$D, this.$H, this.$m, this.$s, this.$ms];
  };
});